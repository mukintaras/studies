#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	int n;
	scanf("%d", &n);
	printf("%o\n", n);

	return 0;
}