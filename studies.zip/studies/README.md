This is a repo for my study projects and stuff
