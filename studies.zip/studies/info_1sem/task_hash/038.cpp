#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define abs(n) (n<0)?(-n):n;

int main()
{
	double a, b, c, d, e;

	scanf("%lg%lg%lg%g%lg", &a, &b, &c, &d, &e);

	if ((a == 0) && (b == 0) && (c == 0) && (d == 0) && (e == 0))
	{
		printf("NO\n");
	}
	else
		if ((a == 0) && (b == 0) && (c == 0))
		{
			
		}

	return 0;
}