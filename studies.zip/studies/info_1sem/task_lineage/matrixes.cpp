#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void tr(double a[1000][1000], int n)
{
	for (int i = 0; i < n; ++i)
	{
		for (int j = i+1; j < n; ++j)
		{
			
		}
	}
}

int main()
{
	
	return 0;
}