#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	int a, b;
	scanf("%x %x", &a, &b);
	printf("%x\n", a^b);

	return 0;
}