	struct Rect0 a;
	struct Rect1 b;
	
	a.x = -7;
	a.y = 5;
	a.width = 12;
	a.height = 8;

	b.lt.x = -7;
	b.lt.y = 5;
	b.rb.x = 5;
	b.rb.y = -3;