// #include <stdio.h>
// #include <stdlib.h>
// #include <math.h>
// typedef int Smith;

// int main()
// {
// 	Smith x; int N;
	x = (Smith *)calloc(N, sizeof(Smith));

// 	return 0;
// }